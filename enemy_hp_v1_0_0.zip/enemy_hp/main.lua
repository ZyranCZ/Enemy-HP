-- Enemy HP Readout for Gen1Recomp
--
-- Gen 1 shows the foe's HP as a bar and nothing else.  This puts the figure
-- on the same row as its level.
--
-- MAKING ROOM
--
-- Vanilla leaves columns 1-3 of that row empty and starts the level block
-- at column 4: the <LV> tile at 4, the number at 5.  The foe's pic begins
-- at hlcoord 12,0, so the row runs out at column 11.  That leaves four
-- columns after a two-digit level -- enough for a percentage, not for
-- "24/57", and nowhere near "352/705".
--
-- Sliding the level block into the empty columns fixes that.  <LV> moves to
-- column 1 and the number to column 2, which frees:
--
--     level 23   ->  columns 5-11, 7 wide     "352/705" fits
--     level 100  ->  columns 6-11, 6 wide     "24/57" fits, the widest does not
--     PSN        ->  columns 5-11, 7 wide
--
-- One blank column always stays between the level and the figure, and the
-- figure is right-aligned to column 11 so it never drifts as digits come
-- and go.  Widths are measured, not assumed, so a longer status label or a
-- wider level from another mod shortens the figure rather than letting it
-- run under the sprite.  NUMBERS falls back to a percentage when the row is
-- too tight, and a percentage always fits.
--
-- HOW IT DRAWS
--
-- Not through battle.overlay: that hook runs after drawZonePass has
-- recoloured the HUD and blitted it, so anything drawn there skips the
-- palette pipeline and sits beside the HUD looking foreign.
--
-- Instead the mod wraps Font.draw and takes over the foe's level draw,
--
--     Font.draw(tostring(self.enemy.mon.level), 40, 8)
--
-- which is that slot uniquely (the player's level is at 120, 64).  Working
-- from inside that call puts everything on the same canvas in the same
-- pass, so the engine colours, fades and palette-maps the figure exactly
-- as it does the level beside it.  The HUD shake wraps this block in a
-- translate, so the whole row rides along with it too.
--
-- Hanging off the level also inherits its visibility: the HUD block is
-- gated on the intro slide, the trainer pic, the send-out, the grow-in and
-- the faint.  No level drawn, no readout, and no duplicate gate to keep in
-- sync with the engine.
--
-- The <LV> tile cannot be intercepted the same way -- BattleState captured
-- it as a local upvalue (`local hudTile = HudTiles.tile`) when the module
-- loaded, so patching HudTiles afterwards would not reach it.  It is
-- already on the canvas by the time the level draws, so the mod paints that
-- one cell back to the field's white and redraws the tile at its new home.

local EXACT, PERCENT = "exact", "percent"

local FORMAT_CHOICES = {
  { "NUMBERS", EXACT },
  { "PERCENT", PERCENT },
}

local ROW_Y = 8            -- the level row
local ANCHOR_X = 40        -- where the engine draws the level / status label
local LV_TILE_X = 32       -- where the engine draws the <LV> tile
local LV_TILE_CODE = 0x6E

-- The level block's new home.  Column 1 sat flush against the left edge of
-- the HUD chrome and read as falling out of it, so it starts at column 2;
-- every column further right costs one column of figure width.
local SHIFTED_TILE_X = 16  -- column 2
local SHIFTED_TEXT_X = 24  -- column 3

-- The Gen 1 font has no "%" -- Font.encode falls back to SPACE, which is an
-- opaque white tile, so a percentage would print with a blank block where
-- the sign belongs.  The mod ships the glyph as its own font page.
local PERCENT_CODE = 0x140
local LAST_FREE_COL = 11   -- the foe's pic starts at column 12

return function(mod)
  local Font = mod.ui.Font
  local HudTiles = require("src.render.HudTiles")

  mod.content.font:register("enemy_hp_percent", {
    image = mod.assets:path("assets/percent.png"),
    base = PERCENT_CODE, glyphsPerRow = 1,
  })
  mod.content.font:register("charmap:enemy_hp_percent", {
    seq = "%", code = PERCENT_CODE,
  })

  mod.options:define({
    { key = "enabled", label = "ENEMY HP", type = "toggle", default = true },
    { key = "format", label = "ENEMY HP AS", type = "choice",
      default = EXACT, choices = FORMAT_CHOICES },
  })

  local enabled, format

  local function readOptions()
    enabled = mod.options:get("enabled") and true or false
    format = mod.options:get("format") == PERCENT and PERCENT or EXACT
  end

  readOptions()
  mod.events:on("mod.options_changed", function(payload)
    if payload and payload.mod == "enemy_hp" then readOptions() end
  end)

  -- Font.draw has no idea which battle is on screen, so the current one is
  -- kept here.  battle.started / battle.ended bracket every battle.
  local current
  mod.events:on("battle.started", function(payload)
    current = payload and payload.battle
  end)
  mod.events:on("battle.ended", function() current = nil end)

  -- The HP the bar is currently showing, which lags mon.hp through the
  -- drain animation.  Reading mon.hp would snap the number to its final
  -- value while the bar was still sliding.
  local function shownHP(battler)
    local shown = battler.shownHP
    if shown == nil then shown = battler.mon and battler.mon.hp end
    return shown or 0
  end

  local function percentText(hp, max)
    -- a foe still standing must never read 0%, and one at full HP must read
    -- 100 rather than 99 from a floor
    local pct = hp <= 0 and 0 or math.max(1, math.floor(hp * 100 / max))
    return ("%d%%"):format(pct)
  end

  -- What to draw on the level row: the figure, its x, and where the shifted
  -- level block goes.  nil means leave the row exactly as vanilla drew it.
  local function layout(battle, anchorText)
    if not enabled or not battle then return nil end

    local enemy = battle.enemy
    local stats = enemy and enemy.mon and enemy.mon.stats
    local max = stats and stats.hp
    if not max or max <= 0 then return nil end

    local hp = math.max(0, math.min(shownHP(enemy), max))
    local label = tostring(anchorText or "")

    -- the level block moves to column 1; a status label takes the tile's
    -- place instead of sitting after it
    local statused = enemy.shownStatus ~= nil
    local textX = statused and SHIFTED_TILE_X or SHIFTED_TEXT_X
    local endCol = textX / 8 + #label - 1

    -- one blank column between the level block and the figure
    local free = LAST_FREE_COL - endCol - 1
    if free < 1 then return nil end

    local text = format == EXACT and ("%d/%d"):format(hp, max)
                                  or percentText(hp, max)
    if #text > free then
      -- NUMBERS is too wide for this row; a percentage always fits
      text = percentText(hp, max)
      if #text > free then
        -- only a level-100 foe at exactly full health lands here: "100%"
        -- is four and the row leaves three.  Dropping the sign beats a
        -- blank that fills in after the first hit, which reads as a bug.
        text = text:gsub("%%$", "")
        if #text > free then return nil end
      end
    end

    return {
      text = text,
      textX = (LAST_FREE_COL + 1 - #text) * 8,
      labelX = textX,
      tile = not statused,
    }
  end

  -- our own draws go back through the wrapped function; do not re-enter
  local drawing = false

  local vanillaDraw = Font.draw
  Font.draw = function(text, x, y)
    if drawing or x ~= ANCHOR_X or y ~= ROW_Y or not current then
      return vanillaDraw(text, x, y)
    end

    local plan = layout(current, text)
    if not plan then return vanillaDraw(text, x, y) end

    drawing = true
    -- the engine already put <LV> at column 4; clear that one cell back to
    -- the field white drawClassic filled the canvas with
    -- the font's space glyph is an opaque white tile, which is how the
    -- engine itself blanks a cell -- and unlike a raw white rectangle it
    -- goes through the same palette pass as everything else on the row
    vanillaDraw(" ", LV_TILE_X, ROW_Y)
    if plan.tile then
      HudTiles.tile(LV_TILE_CODE, SHIFTED_TILE_X, ROW_Y)
    end
    vanillaDraw(text, plan.labelX, ROW_Y)
    vanillaDraw(plan.text, plan.textX, ROW_Y)
    drawing = false
  end

  mod.exports.layout = layout
end
