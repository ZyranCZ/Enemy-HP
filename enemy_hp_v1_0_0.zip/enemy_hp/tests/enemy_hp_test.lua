-- Drives the readout with a stubbed font and tile sheet, so it runs with no
-- graphics context.  Run from the game root:  lua tests/enemy_hp_test.lua
package.path = "./?.lua;./?/init.lua;" .. package.path

local modPath = os.getenv("ENEMY_HP_MAIN") or "mods/enemy_hp/main.lua"

local drawn, tiles, cleared = {}, {}, {}

package.loaded["src.render.HudTiles"] = {
  tile = function(code, x, y) tiles[#tiles + 1] = { code = code, x = x, y = y } end,
}

love = { graphics = {
  setColor = function() end,
  rectangle = function(_, x, y, w, h)
    cleared[#cleared + 1] = { x = x, y = y, w = w, h = h }
  end,
} }

local fakeFont = { draw = function(text, x, y)
  drawn[#drawn + 1] = { text = text, x = x, y = y }
end }

local options = { enabled = true, format = "exact" }
local listeners = {}

local registered = {}

local mod = {
  content = { font = { register = function(_, id, value)
    registered[id] = value
  end } },
  assets = { path = function(_, p) return p end },
  options = { define = function() end, get = function(_, k) return options[k] end },
  events = { on = function(_, name, fn)
    listeners[name] = listeners[name] or {}
    table.insert(listeners[name], fn)
  end },
  hooks = { wrap = function() end },
  ui = { Font = fakeFont },
  exports = {},
  log = { info = function() end, warn = function() end },
}

assert(loadfile(modPath), "cannot load " .. modPath)()(mod)

local function emit(name, payload)
  for _, fn in ipairs(listeners[name] or {}) do fn(payload) end
end

local function setOption(key, value)
  options[key] = value
  emit("mod.options_changed", { mod = "enemy_hp", key = key, value = value })
end

local function battle(hp, max, status)
  return { enemy = {
    mon = { stats = { hp = max } }, shownHP = hp, shownStatus = status,
  } }
end

-- what the HUD pass produces when it reaches the enemy level slot
local function drawRow(levelText)
  drawn, tiles, cleared = {}, {}, {}
  fakeFont.draw(levelText or "23", 40, 8)
  return drawn
end

local failures = 0
local function check(label, got, want)
  local ok = got == want
  if not ok then failures = failures + 1 end
  print(("%-58s %s  (got %s, want %s)")
    :format(label, ok and "PASS" or "FAIL", tostring(got), tostring(want)))
end

-- the level block slides into the empty columns 1-3
emit("battle.started", { battle = battle(24, 57) })
local out = drawRow("23")
check("the level itself is still drawn", out[2] and out[2].text, "23")
check("the old <LV> cell is blanked first", out[1] and out[1].text, " ")
check("the blank lands on the old cell", out[1] and out[1].x, 32)
check("the level moves to column 3", out[2] and out[2].x, 24)
check("the level keeps its row", out[2] and out[2].y, 8)
check("the <LV> tile is redrawn at column 2", tiles[1] and tiles[1].x, 16)
check("no raw rectangle is painted", #cleared, 0)

-- which is what buys room for hp/max
check("numbers still fit", out[3] and out[3].text, "24/57")
-- right-aligned to column 11: five characters start at column 7
check("figure is right-aligned to column 11", out[3] and out[3].x, 56)
check("figure shares the level row", out[3] and out[3].y, 8)

-- the missing "%" glyph is supplied by the mod rather than printing blank
check("a percent glyph page is registered",
      registered["enemy_hp_percent"] ~= nil, true)
check("and mapped to the % character",
      registered["charmap:enemy_hp_percent"].seq, "%")

-- the widest figure Gen 1 can produce fits beside a two-digit level
emit("battle.started", { battle = battle(352, 705) })
check("the widest figure gives way to percent",
      drawRow("23")[3].text, "49%")

-- a three-digit level costs a column, so the widest figure gives way
emit("battle.started", { battle = battle(352, 705) })
check("level 100 falls back to percent", drawRow("100")[3].text, "49%")
emit("battle.started", { battle = battle(24, 57) })
check("level 100 still fits a short figure", drawRow("100")[3].text, "24/57")

-- a status label replaces the <LV> tile rather than following it
emit("battle.started", { battle = battle(24, 57, "PSN") })
out = drawRow("PSN")
check("status label moves to column 2", out[2].x, 16)
check("no <LV> tile is drawn for a status", #tiles, 0)
check("numbers still fit beside a status", out[3].text, "24/57")

-- percent mode
setOption("format", "percent")
emit("battle.started", { battle = battle(24, 57) })
check("percent rounds down", drawRow("23")[3].text, "42%")
emit("battle.started", { battle = battle(57, 57) })
check("percent at full health is 100", drawRow("23")[3].text, "100%")
emit("battle.started", { battle = battle(1, 400) })
check("one hp left never reads 0%", drawRow("23")[3].text, "1%")
emit("battle.started", { battle = battle(0, 57) })
check("fainted reads 0%", drawRow("23")[3].text, "0%")
setOption("format", "exact")

-- shownHP is the bar's drained value, not the raw current HP
local draining = battle(40, 57)
draining.enemy.mon.hp = 12
emit("battle.started", { battle = draining })
check("follows the bar, not the raw hp", drawRow("23")[3].text, "40/57")

-- an over-wide level slot leaves the row exactly as vanilla drew it
emit("battle.started", { battle = battle(24, 57) })
out = drawRow("PARALYZED")
check("over-wide anchor draws nothing extra", #out, 1)
check("over-wide anchor leaves the level put", out[1].x, 40)
check("over-wide anchor blanks nothing", out[1].text, "PARALYZED")

-- visibility is inherited from the level draw
emit("battle.started", { battle = battle(24, 57) })
drawn = {}
fakeFont.draw("RED", 88, 56)
check("no readout without the level anchor", #drawn, 1)

emit("battle.ended", {})
out = drawRow("23")
check("nothing after the battle ends", #out, 1)
check("and the level is left where vanilla put it", out[1].x, 40)

-- guards
emit("battle.started", { battle = { enemy = {} } })
check("no stats, no readout", #drawRow("23"), 1)
emit("battle.started", { battle = battle(0, 0) })
check("zero max hp is not divided by", #drawRow("23"), 1)

emit("battle.started", { battle = battle(24, 57) })
setOption("enabled", false)
out = drawRow("23")
check("disabled mod draws only the level", #out, 1)
check("disabled mod does not move the level", out[1].x, 40)
setOption("enabled", true)
check("re-enabling restores the readout", #drawRow("23"), 3)

-- the mod's own draws must not re-enter the wrapper
check("no recursion through the wrapper", #drawRow("23"), 3)

-- everything else in the game is untouched
drawn = {}
fakeFont.draw("FIGHT", 80, 112)
fakeFont.draw("23", 120, 64)          -- the player's level slot
check("unrelated draws pass through", #drawn, 2)
check("the player's level is not moved", drawn[2].x, 120)

print(failures == 0 and "\nall checks passed"
                    or ("\n" .. failures .. " check(s) failed"))
os.exit(failures == 0 and 0 or 1)
