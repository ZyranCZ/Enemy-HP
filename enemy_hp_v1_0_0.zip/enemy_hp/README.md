# Enemy HP Readout

Gen 1 shows the foe's HP as a bar and nothing else. This puts the figure on the
same row as its level — as `24/57` or as `42%`.

## Try it

1. Copy the `enemy_hp` folder into the game's `mods/` directory.
2. Launch the game, press **F10**, enable **Enemy HP Readout**.
3. Start a battle.

## Options

| Row | Values | Default |
| --- | --- | --- |
| `ENEMY HP` | ON / OFF | ON |
| `ENEMY HP AS` | NUMBERS / PERCENT | NUMBERS |

`NUMBERS` does reveal the foe's **maximum** HP, which the original never tells
you. `PERCENT` keeps that unknown.

## Making room

Vanilla leaves columns 1-3 of that row empty and starts the level block at
column 4 — the `<LV>` tile at 4, the number at 5. The foe's pic begins at
hlcoord 12,0, so the row runs out at column 11. That leaves four columns after
a two-digit level: enough for a percentage, not for `24/57`.

Sliding the level block into the empty columns fixes it. `<LV>` moves to column
2 and the number to column 3, which frees:

```
level 23   ->  columns 6-11, 6 wide     "24/57" fits
level 100  ->  columns 7-11, 5 wide     "24/57" fits
PSN        ->  columns 6-11, 6 wide
```

Column 1 was tried first and read as falling out of the left edge of the HUD
chrome, so the block starts at column 2. Every column further right costs one
column of figure width; at column 2 the widest figures Gen 1 can produce
(`352/705`) give way to a percentage, and everything shorter fits.

One blank column always stays between the level block and the figure, and the
figure is right-aligned to column 11 so it never drifts as digits come and go.
Widths are measured rather than assumed, so a longer status label or a wider
level from another mod shortens the figure instead of letting it run under the
sprite. `NUMBERS` falls back to a percentage when the row is too tight.

## It matches the rest of the HUD exactly

Not by imitation. The obvious hook, `battle.overlay`, draws too late: in
colorized modes the HUD is rendered into an offscreen canvas and then
recoloured by region, and the overlay runs after all of that. Text drawn there
skips the palette pipeline and sits beside the HUD looking foreign.

So the mod wraps `Font.draw` and takes over the foe's level draw — uniquely at
(40, 8). Working from inside that call puts everything on the same canvas in
the same pass, so the engine colours, fades and palette-maps the figure exactly
as it does the level beside it. The HUD shake wraps this block in a translate,
so the whole row rides along with it too.

Hanging off the level also inherits its visibility. The enemy HUD clears on the
intro text, during a send-out and the grow-in, and after a faint — if the level
is not being drawn, neither is this, and there is no duplicate gate to keep in
sync.

The `<LV>` tile cannot be intercepted the same way: `BattleState` captured it as
a local upvalue when the module loaded, so patching `HudTiles` afterwards would
not reach it. It is already on the canvas by the time the level draws, so the
mod blanks that cell and redraws the tile at its new home. Blanking is done by
drawing the font's space glyph — an opaque white tile, which is how the engine
itself clears a cell — rather than a raw white rectangle, so it goes through
the same palette pass as everything else on the row.

## The missing percent sign

Gen 1's font has no `%`. `Font.encode` falls back to the space glyph for any
character it cannot find, so a percentage would print with a blank white block
where the sign belongs. The mod ships the glyph as its own font page
(`assets/percent.png`) with a charmap entry mapping `%` to it, which is the
supported way to add a character without touching the vanilla sheets.

The value shown is the one the bar's drain animation has reached, not the raw
current HP, so the number and the bar stay in step.

## Tests

`tests/enemy_hp_test.lua` drives the layout with a stubbed font and tile sheet,
so it runs without a graphics context:

```
lua tests/enemy_hp_test.lua
```
